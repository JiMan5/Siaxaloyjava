package src;

import java.awt.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Graphics {

    int width;
    int height;
    int x;
    int y;
    
    int rows;
    int cols;
    
    static GraphicsConfiguration gc;

    BoardPanel boardPanel;
    JLabel label = new JLabel();
    JFrame frame = new JFrame(gc);
    
    public Graphics(Board board, int width, int height, int x, int y, int rows, int cols){
        this.cols = cols;
        this.rows = rows;
        
        frame.setTitle("Theseus and Minotaur");
        frame.setSize(width, height);
        frame.setLocation(x, y);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        boardPanel = new BoardPanel(board);
        boardPanel.add(label);        

    }

    public void updateFrame(String text, Board board){
        
        boardPanel.setBoard(board);
        label.setText(text);
        frame.add(boardPanel);

        frame.validate();
        frame.repaint();

    }

    public class BoardPanel extends JPanel{

        private static final long serialVersionUID = 1L;

        Board board;

        static final int originX = 270;
        static final int originY = 35;
        static final int cellSide = 35;

        public BoardPanel(Board board){
            this.board = board;
        }

        public Board getBoard() {
            return board;
        }

        public void setBoard(Board board) {
            this.board = board;
        }

        @Override
        protected void paintComponent(java.awt.Graphics g) {
            super.paintComponent(g);

            Color color = new Color(224, 180, 100, 100);
            g.setColor(color);
            g.fillRect(originX, originY, cols * cellSide, rows * cellSide);
            g.setColor(Color.BLACK);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(1));

            for(int i = 0; i < rows + 1; i++){
                for(int j = 0; j < cols; j++){
                    if(i != rows){
                        if(board.tiles[(cols - 1 - i) * cols + j].getUp()) g2.setStroke(new BasicStroke(5));
                    }
                    else g2.setStroke(new BasicStroke(5));
                    g.drawLine(originX + j * cellSide, originY + cellSide * i, originX + (j + 1) * cellSide, originY + cellSide * i);
                    g2.setStroke(new BasicStroke(1));
                }
            }

            for(int i = 0; i < cols + 1; i++){
                for(int j = 0; j < rows; j++){
                    if(i != cols){
                        if(board.tiles[(cols - 1 - j) * cols + i].getLeft()) g2.setStroke(new BasicStroke(5));
                    }
                    else g2.setStroke(new BasicStroke(5));
                    g.drawLine(originX + i * cellSide, originY + cellSide * j, originX + i * cellSide, originY + cellSide * (j + 1));
                    g2.setStroke(new BasicStroke(1));
                }
            }

            drawSupplies(g2);

        }

        public Image getSupplyImage(){
            ImageIcon imageIcon = new ImageIcon("C:/Code/Java/ERGASIA/images/supplyPurple.png");
            Image image = imageIcon.getImage();
            Image newImage = image.getScaledInstance(25, 25, Image.SCALE_AREA_AVERAGING);
            imageIcon = new ImageIcon(newImage);
            return imageIcon.getImage();
        }

        public void drawSupplies(Graphics2D g2d){
            for(int i = 0; i < board.getS(); i++){
                if(board.supplies[i].getSupplyTileId() != 0){

                    int imgx = originX + board.supplies[i].getY() * cellSide;
                    int imgy = originY + (cols - 1 - board.supplies[i].getX()) * cellSide;
    
                    g2d.drawImage(getSupplyImage(), imgx + 5, imgy + 5, null);

                }
            }
        }
        
    }

}