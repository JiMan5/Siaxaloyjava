package src;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Graphics {

    Board board;

    int width;
    int height;
    int x;
    int y;
    
    int rows;
    int cols;

    JLabel label = new JLabel("Game has started! Round: 0");
    
    static GraphicsConfiguration gc;

    public Graphics(Board board, int width, int height, int x, int y, int rows, int cols){
        this.board = board;
        this.cols = cols;
        this.rows = rows;

        JFrame frame = new JFrame(gc);
        frame.setTitle("Theseus and Minotaur");
        frame.setSize(width, height);
        frame.setLocation(x, y);
        
        BoardPanel boardPanel = new BoardPanel();
        boardPanel.add(label);
        frame.add(boardPanel);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

    }

    public void updateText(String text){
        this.label.setText(text);
    }

    public class BoardPanel extends JPanel{

        private static final long serialVersionUID = 1L;

        static final int originX = 270;
        static final int originY = 35;
        static final int cellSide = 35;

        @Override
        protected void paintComponent(java.awt.Graphics g) {
            super.paintComponent(g);

            Color color = new Color(224, 180, 100, 100);
            g.setColor(color);
            g.fillRect(originX, originY, cols * cellSide, rows * cellSide);
            g.setColor(Color.BLACK);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(1));

            for(int i = 0; i < rows + 1; i++){
                for(int j = 0; j < cols; j++){
                    if(i != rows){
                        if(board.tiles[(cols - 1 - i) * cols + j].getUp()) g2.setStroke(new BasicStroke(3));
                    }
                    else g2.setStroke(new BasicStroke(3));
                    g.drawLine(originX + j * cellSide, originY + cellSide * i, originX + (j + 1) * cellSide, originY + cellSide * i);
                    g2.setStroke(new BasicStroke(1));
                }
            }

            for(int i = 0; i < cols + 1; i++){
                for(int j = 0; j < rows; j++){
                    if(i != cols){
                        if(board.tiles[(cols - 1 - j) * cols + i].getLeft()) g2.setStroke(new BasicStroke(3));
                    }
                    else g2.setStroke(new BasicStroke(3));
                    g.drawLine(originX + i * cellSide, originY + cellSide * j, originX + i * cellSide, originY + cellSide * (j + 1));
                    g2.setStroke(new BasicStroke(1));
                }
            }

        }
        
    }

}