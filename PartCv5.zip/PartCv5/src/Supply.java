package src;
//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)

public class Supply {
    
    int supplyId;           // το id του εφοδίου
    int x;                  // η συντεταγμένη x του πλακιδίου του ταμπλό όπου βρίσκεται το εφόδιο
    int y;                  // η συντεταγμένη y του πλακιδίου του ταμπλό όπου βρίσκεται το εφόδιο
    int supplyTileId;       // το id του πλακιδίου του ταμπλό όπου βρίσκεται to εφόδιο

    public Supply(){        // κενός constructor
        supplyId = 0;
        x = 0;              
        y = 0;
        supplyTileId = 0;
    }

    public Supply(int supplyId, int x, int y, int supplyTileId){        // constructor με ορίσματα
        this.supplyId = supplyId;
        this.x = x;
        this.y = y;
        this.supplyTileId = supplyTileId;
    }

    public Supply(Supply supply){                   // constructor με όρισμα ένα αντικείμενο Supply
        
        Supply clone = new Supply(supply.supplyId, supply.x, supply.y, supply.supplyTileId);

        supplyId = clone.supplyId;
        x = clone.x;
        y = clone.y;
        supplyTileId = clone.supplyTileId;

    }

    // ακολουθούν οι setters και οι getters όλων των μεταβλητών της κλάσης Supply

    public void setSupplyId(int supplyId){      
        this.supplyId = supplyId;
    }

    public int getSupplyId(){      
        return supplyId;
    }

    public void setX(int x){
        this.x = x;
    }

    public int getX(){
        return x;
    }

    public void setY(int y){
        this.y = y;
    }

    public int getY(){
        return y;
    }

    public void setSupplyTileId(int supplyTileId){
        this.supplyTileId = supplyTileId;
    }

    public int getSupplyTileId(){
        return supplyTileId;
    }

}