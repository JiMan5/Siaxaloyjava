package src;
//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)


public class Game {
    int round; // ο τρέχον γύρος του παιχνιδιού

    public Game(){ // κενός constructor
        round = 0;
    }
    public Game(int round){ // constructor με ορίσματα
        this.round = round;
    }

    // setters και getters
    public int getRound(){
        return round;
    }
    public void setRound(int round){
        this.round = round;
    }
    // τέλος setters και getters

    public void printTable(int theseusTile, int minotaurTile, Board board, Game game){ // τυπώνει το board στη τρέχουσα κατάσταση
        String[][] toString = board.getStringRepresentation(theseusTile, minotaurTile, game); // το string που θα τυπωθεί
        for(int i = 0; i < 2 * board.getN() + 1; i++){
            for(int j = 0; j < board.getN(); j++){
                System.out.print(toString[i][j]);
            }
            System.out.println();
        }
    }

    public void show(boolean winner, int round, Board board, int[] arrT, int[] arrM, int winnerId, int n, int score, Game game, MinMaxPlayer Theseus, int roundtemp, int diceM){ // τυπώνει το status του παιχνιδιού
        System.out.println("Round: " + round);
        
        printTable(arrT[0], arrM[0], board, game);
        System.out.println(round % 2 == 1 ? ("Theseus is at tile " + arrT[0] + ".") : ("Minotaur is at tile " + arrM[0] + "."));
        
        if(game.getRound()%2 == 1){
            System.out.println("Score: " + score);
            MinMaxPlayer.statistics(roundtemp, Theseus, Theseus.path, n, round, winner);
        }
        else{
            switch(diceM){
                case 1: System.out.println("Minotaur decided to move up."); System.out.println(); break;
                case 3: System.out.println("Minotaur decided to move right."); System.out.println(); break;
                case 5: System.out.println("Minotaur decided to move down."); System.out.println(); break;
                case 7: System.out.println("Minotaur decided to move left."); System.out.println(); break;
                default: break;
            }
        }
        if(winnerId == 1){
            System.out.println("Theseus won!");
        }
        else if(winnerId == 2){
            System.out.println("The Minotaur won!");
            MinMaxPlayer.statistics(roundtemp, Theseus, Theseus.path, n, round, winner);
        }
        
        else if(round == 2 * n){
            System.out.println("Game took way too long... Theseus died of starvation and Minotaur of boredom!");
            System.out.println();
            MinMaxPlayer.statistics(roundtemp, Theseus, Theseus.path, n, round + 1, winner);
        }
        
    }

    public static void main(String[] args) { // η main μέθοδος του παιχνιδιού
        int N = 5; // μέγεθος του πίνακα
        int S = 4; // αριθμός εφοδίων
        int W = 25; //(N * N * 3 + 1) / 2; // μέγιστος αριθμός τοιχών
        int n = 10; // αριθμός γύρων

        Game game = new Game(); // αντικείμενο τύπου Game
        Board board = new Board(N, S, W); // αντικείμενο τύπου Board
        board.createBoard();
        if(game.getRound() == 0){
            System.out.println("The Game begins. The initial board is as such."); 
            System.out.println("Round: 0");
        }
        game.printTable(0, (N * N) / 2, board, game);

        MinMaxPlayer Theseus = new MinMaxPlayer(1, "Theseus", 0, 0, 0, board); // παίκτης Θησέας
        HeuristicPlayer Minotaur = new HeuristicPlayer(2, "Minotaur", 0, N / 2, N / 2, board); // παίκτης Μινώταυρος

        boolean winner = false; // μεταβλητή για τον έλεγχο ύπαρξης νικητή
        int winnerId = 0; // 1 = Θησέας, 2 = Μινώταυρος

        int[] arrT = new int[4]; // πίνακας που θα επιστραφεί απο την μέθοδο move() του Player 1
        int[] arrM = new int[4]; // πίνακας που θα επιστραφεί απο την μέθοδο move() του Player 2
        arrM[0] = (N * N / 2);
        arrT[0] = 0;
        int diceM = 0;
        int roundtemp = 0;
        while(game.getRound() < (2 * n) && !winner){
            if(game.getRound() % 2 == 0){
                int diceT = Theseus.getNextMove(arrT[0], roundtemp, arrM);
                roundtemp++;
                arrT = Theseus.move((Theseus.getX()*N)+Theseus.getY(), diceT, board);
            }
            else{
                diceM = Minotaur.getNextMove(arrM[0], arrT);
                arrM = Minotaur.move((Minotaur.getX()*N)+Minotaur.getY(), diceM, board);
            }
            if(arrT[0] == arrM[0]){
                winner = true;
                winnerId = 2;
            }
            if(Theseus.getScore() == S){
                winner = !winner;
                winnerId = 1;
            } 
            
            game.setRound(game.getRound() + 1);
            game.show(winner, game.getRound(), board, arrT, arrM, winnerId, n, Theseus.getScore(), game, Theseus, roundtemp, diceM);
        }
    }
}
