package src;

import java.util.ArrayList;

public class Node {
    Node parent; //ο κόμβος-πατέρας του κόμβου που δημιουργήσατε.
    Node stepSon; //κρατάει temporarily το προηγούμενο min/max node.
    ArrayList<Node> children = new ArrayList<>(); //ο δυναμικός πίνακας που περιλαμβάνει τα παιδιά του κόμβου που δημιουργήσατε.
    int nodeDepth; //το βάθος του κόμβου στο δέντρο του MinMax Αλγορίθμου.
    int[] nodeMove; //την κίνηση που αντιπροσωπεύει το Node, σαν πίνακας ακεραίων που περιλαμβάνει το x, y του πλακιδίου της τρέχουσας θέσης και τον αριθμό του ζαριού.
    Board nodeBoard; //το ταμπλό του παιχνιδιού για το συγκεκριμένο κόμβο-κίνηση.
    double nodeEvaluation;  //την τιμή της συνάρτησης αξιολόγησης της κίνησης που αντιπροσωπεύει ο συγκεκριμένος κόμβος.

    public Node(){
        // empty constructor
    }

    public Node(Node parent, int nodeDepth, int[] nodeMove, Board nodeBoard, double nodeEvaluation){
        this.parent = parent;
        this.nodeDepth = nodeDepth;
        this.nodeMove = nodeMove;
        this.nodeBoard = nodeBoard;
        this.nodeEvaluation = nodeEvaluation;
    }
    
    //start of setters and getters

    public Node getStepSon() {
        return stepSon;
    }

    public Node getParent() {
        return parent;
    }
    
    public ArrayList<Node> getChildren() {
        return children;
    }

    public int getNodeDepth() {
        return nodeDepth;
    }

    public int[] getNodeMove() {
        return nodeMove;
    }

    public Board getNodeBoard() {
        return nodeBoard;
    }

    public double getNodeEvaluation() {
        return nodeEvaluation;
    }

    public void setStepSon(Node stepSon) {
        this.stepSon = stepSon;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public void setChildren(ArrayList<Node> children) {
        this.children = children;
    }

    public void setNodeDepth(int nodeDepth) {
        this.nodeDepth = nodeDepth;
    }

    public void setNodeMove(int[] nodeMove) {
        this.nodeMove = nodeMove;
    }

    public void setNodeBoard(Board nodeBoard) {
        this.nodeBoard = nodeBoard;
    }

    public void setNodeEvaluation(double nodeEvaluation) {
        this.nodeEvaluation = nodeEvaluation;
    }

    //end of setters and getters

}
