package src;

import java.util.ArrayList;

public class MinMaxPlayer extends Player {

    ArrayList<int[]> path = new ArrayList<>();

    int treeDepth;

    static int counterUpT = 0; //πόσες φορές κινήθηκε προς τα πάνω ο πάικτης
    static int counterRightT = 0; //πόσες φορές κινήθηκε προς τα δεξιά ο πάικτης
    static int counterDownT = 0; //πόσες φορές κινήθηκε προς τα κάτω ο πάικτης
    static int counterLeftT = 0; //πόσες φορές κινήθηκε προς τα αριστερά ο πάικτης
    
    static int previousMove = 0;

    static int counterSupplies = 0; //πόσα supplies βρήκε ο παίκτης

    static int counterRound = 0;

    public MinMaxPlayer(){ //κενός constructor
        super();
        treeDepth = 0;
    }

    public MinMaxPlayer(int treeDepth, int playerId, String name, int score, int x, int y, Board board){ // constructor της κλάσης MinMaxPlayer με ορίσματα
        super(playerId, name, score, x, y, board);
        this.treeDepth = treeDepth;
    }

    public double targetFunction(int supplyDist, int opponentDist){ 
        //
        double sup = 0.0;
        double opp = 0.0;
        switch (supplyDist){ //ανάλογα με την απόσταση από το supply δίνεται μια τιμή πόντων
            case -1: sup = -2.0; break;
            case  0: sup =  0.0; break;
            case  1: sup =  1.0; break;
            case  2: sup =  0.5; break;
            case  3: sup =  0.3; break;
            default: break;
        }

        switch (opponentDist){ //ανάλογα με την απόσταση από τον Μινώταυρο δίνεται μια τιμή πόντων
            case -1: opp = 2.0; break;
            case  0: opp = 0.0; break;
            case  1: opp = 1.0; break;
            case  2: opp = 0.5; break;
            case  3: opp = 0.3; break;
            default: break;
        }
        return sup * 0.46 + (-opp) * 0.54; //επιστρέφει την αξία της κίνησης
    }

    public double[] evaluate(int currentPos, int dice, int[] arrM, Board board){
        //
        int supplyDist = 0;
        int opponentDist = 0;
        Board clone = new Board(board);
        MinMaxPlayer clonePlayer = new MinMaxPlayer(0, this.playerId, this.name, this.score, this.x, this.y, clone);
        ArrayList<int[]> info = new ArrayList<>(); //μεταβλητη που κραταει πληροφορίες για
        for(int i = 0; i < 3; i++){
            int[] arr = clonePlayer.move(currentPos, dice, clone);
            if(arr[0] == currentPos){                  // found wall
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = -1;                    // -1 αν βρει τοίχος
                tileInfo[2] = -1;
                info.add(tileInfo);
                break;
            }
            if(arrM[0] == arr[0]){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 2;                    // 2 αν βρει τον Μινώταυρο
                tileInfo[2] = 0;
                info.add(tileInfo);
            }
            if(arr[3] != -1){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                if(tileInfo[1] != 2){
                    tileInfo[1] = 1;                // 1 αν βρει supply
                }
                else tileInfo[2] = 1;
                info.add(tileInfo);
            }
            else{
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 0;                    // 0 αν δεν βρει τίποτα
                tileInfo[2] = 0;
                info.add(tileInfo);
            }
            currentPos = arr[0];
        }

        boolean flag = false;
        for(int i = 0; i < 3; i++){
            for(int j = 1; j <= 2; j++){
                if(info.get(i)[j] == 1 && supplyDist == 0){
                    supplyDist = i + 1;
                }
                else if(info.get(i)[j] == 2 && opponentDist == 0){
                    opponentDist = i + 1;
                }
                else if(info.get(i)[j] == -1){
                    if(i == 0){
                        supplyDist = -1;
                        opponentDist = -1;
                    }
                    flag = true;
                    break;
                }
            }
            if(flag) break;
        }

        double[]  pathInfo = new double[5]; //ενημέρωση του path
        pathInfo[0] = targetFunction(supplyDist, opponentDist);
        pathInfo[1] = dice;
        pathInfo[2] = (supplyDist == 1) ? 1 : 0;
        pathInfo[3] = supplyDist;
        pathInfo[4] = opponentDist;


        return pathInfo; //επιστροφή αξίας κίνησης

    }

    /*public int getNextMove(int currentPos, int round, int[] arrM, Board board) {
        //επιλογή της βέλτιστης κίνησης

        ArrayList<double[]> posmove = new ArrayList<>();
        for(int i=0; i<4; i++){
            int dice = 2*i + 1;
            double[] temparr = new double[2];
            temparr[0] = (double)dice;
            temparr[1] = evaluate(currentPos, dice, arrM, board);
            posmove.add(temparr);
        }

        double max = -1000.0;
        int bestdice = 0;
        ArrayList<double[]> postemp= new ArrayList<>();
        for (int i = 0; i<4; i++){
            if(posmove.get(i)[1] >= max){ //εύρεση της κίνησης με την μέγιστη αξία
                max = posmove.get(i)[1];
                bestdice = (int)posmove.get(i)[0];
            }
        }
        for(int i = 0; i < 4; i++){
            if(posmove.get(i)[1] == max){ //εύρεση κίνησης με αξία ισάξια με την μέγιστη (εάν υπάρχει)
                postemp.add(posmove.get(i));
            } 
        }
        
        if(postemp.size() > 1){  //τυχαία επιλογή μιας κίνησης αν υπάρχουν έστω δύο ισάξιες
            while(true){
                int index = (int)((Math.random()*100) % postemp.size());
                bestdice = (int)postemp.get(index)[0];
                if(bestdice != ((previousMove + 4)%8)) break;
            }
        }

        int counter = 0;
        for(int i = round; i < path.size(); i++){
            if(path.get(i)[0] != bestdice){
                path.remove(i);
                i--;
                counter++;
            }
            if(counter == 3) break;
        }
        previousMove = bestdice; 
        //η μέθοδος είναι μη στατική επίτηδες.

        return bestdice;

    }*/

    public static void statistics(int round, MinMaxPlayer player, ArrayList<int[]> path, int n, int realRound, boolean winner){                 
        //Τυπώνει τον γύρο, τις κινήσεις το Θησέα, πόσα supplies έχει συλλέξει, πόσα μακριά βρίσκεται από τον Μινώταυρο, και πόσες είναι οι συνολικές φορές που κινήθηκε ανα κατεύθυνση
        
        //Τυπώνει προς τα που κινείται ο Θησεάς
        if((realRound != 2*n + 1) && !winner){
            if(path.get(round-1)[0]==1){
                System.out.println("Theseus moved up!");
                counterUpT++;
            }
            else if(path.get(round-1)[0]==3){
                System.out.println("Theseus moved right!");
                counterRightT++;
            }
            else if(path.get(round-1)[0]==5){
                System.out.println("Theseus moved down!");
                counterDownT++;
            }
            else if(path.get(round-1)[0]==7){
                System.out.println("Theseus moved left!");
                counterLeftT++;
            }
        }
    
             //Τυπώνει πόσα supplies έχει συλλέξει ο Θησεάς
        
        
        //Τυπώνει πόσες είναι οι συνολικές φορές που κινήθηκε ανα κατεύθυνση
        else{
            System.out.println();
            for(int i = 0; i < path.size(); i++){
                System.out.println("THESEUS' ROUND: " + (++counterRound));
                if(path.get(i)[1] == 1) counterSupplies++;
                System.out.println("Theseus has found " + counterSupplies + " Supply(-ies).");

                if(path.get(i)[2] == 0){
                    System.out.println("There are no supplies in Theseus' visual field");
                }
                else{
                    System.out.println("Theseus was " + path.get(i)[2] + " tile(s) away from a Supply");
                }
                
                if(path.get(i)[3] == 0){
                    System.out.println("Theseus doesn't see the Minotaur.");
                }
                else{
                    System.out.println("Theseus was " + path.get(i)[3] + " tile(s) away from the Minotaur!");
                }
                System.out.println();
            }
            System.out.println();
            System.out.println("GAME STATISTICS:");
            System.out.println("Theseus moved " + counterUpT + " times up");
            System.out.println("Theseus moved " + counterRightT + " times right");
            System.out.println("Theseus moved " + counterDownT + " times down");
            System.out.println("Theseus moved " + counterLeftT + " times left");
        }
    }

    public Node maximum(Node maxEval, Node eval){
        if(maxEval.getStepSon().getNodeEvaluation() > eval.getStepSon().getNodeEvaluation()) return maxEval;
        return eval;
    }

    public Node minimum(Node minEval, Node eval){
        if(minEval.getStepSon().getNodeEvaluation() < eval.getStepSon().getNodeEvaluation()) return minEval;
        return eval;
    }

    public Node chooseMinMaxMove(Node root, boolean maximizingPlayer){
        if(root.getNodeDepth() == this.treeDepth){
            return root;
        }
        if(maximizingPlayer){
            Node maxEval = new Node();
            maxEval.setStepSon(maxEval);
            maxEval.getStepSon().setNodeEvaluation(-100);
            for(int i = 0; i < root.children.size(); i++){
                root.children.get(i).setStepSon(chooseMinMaxMove(root.children.get(i), false));
                maxEval = maximum(maxEval, root.children.get(i));
            }
            return maxEval;
        }
        else{
            Node minEval = new Node();
            minEval.setStepSon(minEval);
            minEval.getStepSon().setNodeEvaluation(100);
            for(int i = 0; i < root.children.size(); i++){
                root.children.get(i).setStepSon(chooseMinMaxMove(root.children.get(i), true));
                minEval = minimum(minEval, root.children.get(i));
            }
            return minEval;
        }
    }

    public int getNextMove(int currentPos, Board board, int[] arrM, HeuristicPlayer Minotaur){ //currentPos = id toy Theseus!
        Node root = new Node();
        Board clone = new Board(board);
        root.setNodeBoard(clone);
        createMySubtree(currentPos, root, 1, arrM, Minotaur);
        Node bestdice = chooseMinMaxMove(root, true); //tha epistrefei node kai apo to node tha pairnoyme to bestdice
        int retDice = bestdice.getNodeMove()[2];
        double[] eval = evaluate(currentPos, retDice, arrM, board);
        int[] inputPath = new int[4];
        for(int i = 1; i < 5; i++){
            inputPath[i-1] = (int)eval[i];
        }
        path.add(inputPath);
        return retDice;
    }

    
    public boolean validMove(int currentPos, int dice, Board board){
        switch (dice) {
            case 1: 
                if(board.tiles[currentPos].getUp()){
                    return false;
                }
                else return true;
            case 3: 
                if(board.tiles[currentPos].getRight()){
                    return false;
                }
                else return true;
            case 5: 
                if(board.tiles[currentPos].getDown()){
                    return false;
                }
                else return true;
            case 7: 
                if(board.tiles[currentPos].getLeft()){
                    return false;
                }
                else return true;
            default:
                return false;
        }
    }
    
    public void createMySubtree(int currentPos, Node root, int depth, int[] arrM, HeuristicPlayer Minotaur){
        if(depth == this.treeDepth) return;
        for(int i = 0; i < 4; i++){
            int dice = 2*i + 1;
            Board clone = new Board(root.getNodeBoard());
            MinMaxPlayer clonePlayer = new MinMaxPlayer(0, this.playerId, this.name, this.score, this.x, this.y, clone);
            
            if(validMove(currentPos, dice, clone)){
                int[] tempArr = clonePlayer.move(currentPos, dice, clone);
                int[] nodeArr = new int[3];
                nodeArr[0] = tempArr[1]; //to x
                nodeArr[1] = tempArr[2]; //to y
                nodeArr[2] = dice; //to dice
                double[] eval = clonePlayer.evaluate(currentPos, dice, arrM, clone);
                System.out.println("Depth: " + depth + "Dice: " + dice + "evaluation: " + eval[0]);
                Node child = new Node(root, depth+1, nodeArr, clone, eval[0]);
                root.children.add(child);
                createOpponentSubtree(tempArr[0], arrM[0], child, depth+1, child.getNodeEvaluation(), Minotaur, tempArr);
            } 
        }
    }

    public void createOpponentSubtree(int currentTheseusPos, int currentMinoPos, Node parent, int depth, double parentEval, HeuristicPlayer Minotaur, int[] arrT){
        if(depth == this.treeDepth) return;
        for(int i = 0; i < 4; i++){
            int dice = 2*i + 1;
            Board clone = new Board(parent.getNodeBoard());
            HeuristicPlayer clonePlayer = new HeuristicPlayer(Minotaur.getPlayerId(), Minotaur.getName(), 0, Minotaur.getX(), Minotaur.getY(), clone);
            
            if(validMove(currentMinoPos, dice, clone)){
                int[] tempArr = clonePlayer.move(currentMinoPos, dice, clone);
                int[] nodeArr = new int[3];
                nodeArr[0] = tempArr[1]; //to x
                nodeArr[1] = tempArr[2]; //to y
                nodeArr[2] = dice; //to dice
                double eval = clonePlayer.evaluate(currentMinoPos, dice, arrT, clone);
                Node child = new Node(parent, depth+1, nodeArr, clone, (eval - parentEval));
                parent.children.add(child);
                createMySubtree(arrT[0], child, depth+1, tempArr, clonePlayer);
            } 
        }
    }



}

