package src;
//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)

public class Player {
    int playerId; //ο κωδικός του παίκτη.
    String name; // το όνομα του παίκτη.
    Board board; // το ταμπλό του παιχνιδιού.
    int score; // το σκορ του παίκτη, το οποίο ανεβαίνει κατά ένα κάθε φορά που βρίσκει ένα εφόδιο.

    int x; //η συντεταγμένη x του πλακιδίου όπου βρίσκεται ο παίκτης
    int y; // η συντεταγμένη y του πλακιδίου όπου βρίσκεται ο παίκτης

    public Player(){ // κενός constructor
        playerId = 0;
        name = " ";
        score = 0;
        x = 0;
        y = 0;
    }
    public Player(int playerId, String name, int score, int x, int y, Board board){ // constructor της κλάσης Player με ορίσματα
        this.playerId = playerId;
        this.name = name;
        this.board = board;
        this.score = score;
        this.x = x;
        this.y = y;
    }
    // εδώ ακολουθούν οι setters και οι getters της κλάσης

    public int getPlayerId(){ 
        return playerId;
    }
    public void setPlayerId(int playerId){
        this.playerId = playerId;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Board getBoard(){
        return board; 
    }
    public void setBoard(Board board){
        this.board = board;
    }
    public int getScore(){
        return score;
    }
    public void setScore(int score){
        this.score = score;
    }
    public int getX(){
        return x;
    }
    public void setX(int x){
        this.x = x;
    }
    public int getY(){
        return y;
    }
    public void setY(int y){
        this.y = y;
    }

    // τέλος setters και getters

    public int[] myMove(int id) { // μέθοδος η οποία γεμίζει τον πίνακα ret[] στην περίπτωση που ο παίχτης βρίσκει εμπόδιο στην κίνησή του 
        int[] ret = new int[4]; // πίνακας int[] που θα επιστραφεί
                ret[0] = id;
                ret[1] = this.x;
                ret[2] = this.y;
                ret[3] = -1; // καθως δεν κουνηθηκε, δεν βρηκε καποιο supply, αρα το supply id = 0s
        return ret;
    }

    public int[] myMoveElse(int id, Board board) { // μέθοδος η οποία γεμίζει τον πίνακα ret[] στην περίπτωση που ο παίχτης μπορεί να κινηθεί
        int[] ret = new int[4]; // πίνακας int[] που θα επιστραφεί
        ret[0] = id;
                ret[1] = this.x;
                ret[2] = this.y;
                ret[3] = -1; // δεν βρηκε supply
                if(board.tiles[id].getSupply() && name.equals("Theseus") && id != 0){
                    for(int i=0; i<board.getS(); i++){
                        if(board.supplies[i].getSupplyTileId() == id){
                            ret[3] = board.supplies[i].getSupplyId(); //βρηκε supply αρα κραταει το id του στην 4η θεση του πινακα
                            board.supplies[i].setX(0);
                            board.supplies[i].setY(0);                      //μηδενισμος των συντεταγμενων του supply που βρηκα
                            board.supplies[i].setSupplyTileId(0);
                            break;
                        }
                    }
                    board.tiles[id].setSupply(false);
                    setScore(getScore() + 1); //αυξανει το τωρινο σκορ κατα 1 αφου βρηκε supply
                }
        return ret;
    }

    public int[] move(int id, int dice, Board board){ // μέθοδος που επιστρέφει την κίνηση του πάικτη
        int[] ret = new int[4]; // πίνακας που θα επιστραφεί
        if(dice == 1){
            if(board.tiles[id].getUp()){ //ελεγχος για εμποδιο μπροστα, ο τοιχος των οριων θεωρειται επισης εμποδιο!
                ret=myMove(id);
                } 
            else{
                this.x = this.x + 1;
                id = id + board.getN();
                ret=myMoveElse(id, board);
                }
        }
        else if(dice == 3){
            if(board.tiles[id].getRight()){ //ελεγχος για εμποδιο δεξια, ο τοιχος των οριων θεωρειται επισης εμποδιο
                ret=myMove(id);
                }   
            else{
                this.y = this.y + 1;
                id = id + 1;
                ret=myMoveElse(id, board);
            }
        }
        else if(dice == 5){
            if(board.tiles[id].getDown()){
                ret=myMove(id);
                }
            else{
                this.x = this.x - 1;
                id = id - board.getN();
                ret=myMoveElse(id, board);
            }
        }
        else if(dice == 7){
            if(board.tiles[id].getLeft()){
                ret=myMove(id);
                }
            else{
                this.y = this.y - 1;
                id = id - 1;
                ret=myMoveElse(id, board);
            }
        }
        return ret;
    }

    
}
