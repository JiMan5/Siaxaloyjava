package src;

import java.util.ArrayList;

public class MinMaxPlayer extends Player {

    ArrayList<int[]> path = new ArrayList<>();

    int treeDepth;

    static int counterUpT = 0; //πόσες φορές κινήθηκε προς τα πάνω ο πάικτης
    static int counterRightT = 0; //πόσες φορές κινήθηκε προς τα δεξιά ο πάικτης
    static int counterDownT = 0; //πόσες φορές κινήθηκε προς τα κάτω ο πάικτης
    static int counterLeftT = 0; //πόσες φορές κινήθηκε προς τα αριστερά ο πάικτης
    
    static int previousMove = 0;

    static int counterSupplies = 0; //πόσα supplies βρήκε ο παίκτης

    static int counterRound = 0;

    public MinMaxPlayer(){ //κενός constructor
        super();
        treeDepth = 0;
    }

    public MinMaxPlayer(int treeDepth, int playerId, String name, int score, int x, int y, Board board){ // constructor της κλάσης MinMaxPlayer με ορίσματα
        super(playerId, name, score, x, y, board);
        this.treeDepth = treeDepth;
    }

    public double targetFunction(int supplyDist, int opponentDist){ 
        //
        double sup = 0.0;
        double opp = 0.0;
        switch (supplyDist){ //ανάλογα με την απόσταση από το supply δίνεται μια τιμή πόντων
            case -1: sup = -2.0; break;
            case  0: sup =  0.0; break;
            case  1: sup =  1.0; break;
            case  2: sup =  0.5; break;
            case  3: sup =  0.3; break;
            default: break;
        }

        switch (opponentDist){ //ανάλογα με την απόσταση από τον Μινώταυρο δίνεται μια τιμή πόντων
            case -1: opp = 2.0; break;
            case  0: opp = 0.0; break;
            case  1: opp = 1.0; break;
            case  2: opp = 0.8; break;
            case  3: opp = 0.5; break;
            default: break;
        }
        return sup * 0.46 + (-opp) * 0.54; //επιστρέφει την αξία της κίνησης
    }

    public double[] evaluate(int currentPos, int dice, int[] arrM, Board board){
        //
        int supplyDist = 0;
        int opponentDist = 0;
        Board clone = new Board(board);
        MinMaxPlayer clonePlayer = new MinMaxPlayer(0, this.playerId, this.name, this.score, this.x, this.y, clone);
        ArrayList<int[]> info = new ArrayList<>(); //μεταβλητη που κραταει πληροφορίες για την επόμενη εικονική κίνηση του Θησέα
        for(int i = 0; i < 3; i++){
            int[] arr = clonePlayer.move(currentPos, dice, clone);
            if(arr[0] == currentPos){                  // found wall
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = -1;                    // -1 αν βρει τοίχος
                tileInfo[2] = -1;
                info.add(tileInfo);
                break;
            }
            if(arrM[0] == arr[0]){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 2;                    // 2 αν βρει τον Μινώταυρο
                tileInfo[2] = 0;
                info.add(tileInfo);
            }
            if(arr[3] != -1){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                if(tileInfo[1] != 2){
                    tileInfo[1] = 1;                // 1 αν βρει supply
                }
                else tileInfo[2] = 1;
                info.add(tileInfo);
            }
            else{
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 0;                    // 0 αν δεν βρει τίποτα
                tileInfo[2] = 0;
                info.add(tileInfo);
            }
            currentPos = arr[0];
        }

        boolean flag = false;
        for(int i = 0; i < 3; i++){
            for(int j = 1; j <= 2; j++){
                if(info.get(i)[j] == 1 && supplyDist == 0){
                    supplyDist = i + 1;
                }
                else if(info.get(i)[j] == 2 && opponentDist == 0){
                    opponentDist = i + 1;
                }
                else if(info.get(i)[j] == -1){
                    if(i == 0){
                        supplyDist = -1;
                        opponentDist = -1;
                    }
                    flag = true;
                    break;
                }
            }
            if(flag) break;
        }

        double[]  pathInfo = new double[5]; //ενημέρωση του path
        pathInfo[0] = targetFunction(supplyDist, opponentDist);
        pathInfo[1] = dice;
        pathInfo[2] = (supplyDist == 1) ? 1 : 0;
        pathInfo[3] = supplyDist;
        pathInfo[4] = opponentDist;


        return pathInfo; //επιστροφή αξίας κίνησης

    }


    public static void statistics(int round, MinMaxPlayer player, ArrayList<int[]> path, int n, int realRound, boolean winner){                 
        //Τυπώνει τον γύρο, τις κινήσεις το Θησέα, πόσα supplies έχει συλλέξει, πόσα μακριά βρίσκεται από τον Μινώταυρο, και πόσες είναι οι συνολικές φορές που κινήθηκε ανα κατεύθυνση
        
        //Τυπώνει προς τα που κινείται ο Θησεάς
        if((realRound != 2*n + 1) && !winner){
            if(path.get(round-1)[0]==1){
                System.out.println("Theseus moved up!");
                counterUpT++;
            }
            else if(path.get(round-1)[0]==3){
                System.out.println("Theseus moved right!");
                counterRightT++;
            }
            else if(path.get(round-1)[0]==5){
                System.out.println("Theseus moved down!");
                counterDownT++;
            }
            else if(path.get(round-1)[0]==7){
                System.out.println("Theseus moved left!");
                counterLeftT++;
            }
        }
    
             
        
        
        
        else{
            System.out.println();
            
            for(int i = 0; i < path.size(); i++){
                //Τυπώνει πόσα supplies έχει συλλέξει ο Θησεάς
                System.out.println("THESEUS' ROUND: " + (++counterRound));
                if(path.get(i)[1] == 1) counterSupplies++;
                System.out.println("Theseus has found " + counterSupplies + " Supply(-ies).");

                //Τυπώνει πόσα supplies έχει συλλέξει ο Θησεάς
                if(path.get(i)[2] == 0){
                    System.out.println("There are no supplies in Theseus' visual field");
                }
                else{
                    System.out.println("Theseus was " + path.get(i)[2] + " tile(s) away from a Supply");
                }
                //Τυπώνει αν ο Θησέας βλέπει τον Μινώταυρο ή οχι (και πόσο μακριά)
                if(path.get(i)[3] == 0){
                    System.out.println("Theseus doesn't see the Minotaur.");
                }
                else{
                    System.out.println("Theseus was " + path.get(i)[3] + " tile(s) away from the Minotaur!");
                }
                System.out.println();
            }

            //Τυπώνει πόσες είναι οι συνολικές φορές που κινήθηκε ανα κατεύθυνση
            System.out.println();
            System.out.println("GAME STATISTICS:");
            System.out.println("Theseus moved " + counterUpT + " times up");
            System.out.println("Theseus moved " + counterRightT + " times right");
            System.out.println("Theseus moved " + counterDownT + " times down");
            System.out.println("Theseus moved " + counterLeftT + " times left");
        }
    }

    public Node maximum(Node maxEval, Node eval){ // επιστρέφει το node με τη μεγαλύτερη τιμή στο evaluation του εικονικού παιδιού του
        if(maxEval.getStepSon().getNodeEvaluation() > eval.getStepSon().getNodeEvaluation()) return maxEval;
        if(maxEval.getStepSon().getNodeEvaluation() == eval.getStepSon().getNodeEvaluation()){
            int index = (int)((Math.random()*100) % 2);
            if(index == 0) return maxEval;
        }
        return eval;
    }

    public Node minimum(Node minEval, Node eval){   // επιστρέφει το node με τη μικρότερη τιμή στο evaluation του εικονικού παιδιού του
        if(minEval.getStepSon().getNodeEvaluation() < eval.getStepSon().getNodeEvaluation()) return minEval;
        if(minEval.getStepSon().getNodeEvaluation() == eval.getStepSon().getNodeEvaluation()){
            int index = (int)((Math.random()*100) % 2);
            if(index == 0) return minEval;
        }
        return eval;
    }

    public Node chooseMinMaxMove(Node root, boolean maximizingPlayer){ // ο αλγόριθμος της MiniMax με επιστροφή ολόκληρο node, δηλαδή μία απο τις 4 κατευθύνσεις
        if(root.getNodeDepth() == this.treeDepth){
            return root;
        }
        if(maximizingPlayer){
            Node maxEval = new Node();
            maxEval.setStepSon(maxEval);
            maxEval.getStepSon().setNodeEvaluation(-100);
            for(int i = 0; i < root.children.size(); i++){
                root.children.get(i).setStepSon(chooseMinMaxMove(root.children.get(i), false));
                maxEval = maximum(maxEval, root.children.get(i));
            }
            return maxEval;
        }
        else{
            Node minEval = new Node();
            minEval.setStepSon(minEval);
            minEval.getStepSon().setNodeEvaluation(100);
            for(int i = 0; i < root.children.size(); i++){
                root.children.get(i).setStepSon(chooseMinMaxMove(root.children.get(i), true));
                minEval = minimum(minEval, root.children.get(i));
            }
            return minEval;
        }
    }


    //O ΙΔΙΟΣ ΑΛΓΟΡΙΘΜΟΣ MINIMAX ΜΕ AB PRUNING

    // public Node chooseMinMaxMove(Node root, boolean maximizingPlayer, Node alpha, Node beta){
    //     if(root.getNodeDepth() == this.treeDepth){
    //         return root;
    //     }
    //     if(maximizingPlayer){
    //         Node maxEval = new Node();
    //         maxEval.setStepSon(maxEval);
    //         maxEval.getStepSon().setNodeEvaluation(-100);
    //         for(int i = 0; i < root.children.size(); i++){
    //             root.children.get(i).setStepSon(chooseMinMaxMove(root.children.get(i), false, alpha, beta));
    //             maxEval = maximum(maxEval, root.children.get(i));
    //             alpha = maximum(alpha, root.children.get(i));
    //             if(beta.getStepSon().getNodeEvaluation() <= alpha.getStepSon().getNodeEvaluation()){
    //                 break;
    //             }
    //         }
    //         return maxEval;
    //     }
    //     else{
    //         Node minEval = new Node();
    //         minEval.setStepSon(minEval);
    //         minEval.getStepSon().setNodeEvaluation(100);
    //         for(int i = 0; i < root.children.size(); i++){
    //             root.children.get(i).setStepSon(chooseMinMaxMove(root.children.get(i), true, alpha, beta));
    //             minEval = minimum(minEval, root.children.get(i));
    //             beta = minimum(beta, root.children.get(i));
    //             if(beta.getStepSon().getNodeEvaluation() <= alpha.getStepSon().getNodeEvaluation()){
    //                 break;
    //             }
    //         }
    //         return minEval;
    //     }
    // }



    public int getNextMove(int currentPos, Board board, int[] arrM, HeuristicPlayer Minotaur, MinMaxPlayer Theseus){ // Η συνάρτηση αυτή φτιάχνει το δέντρο και καλεί την minimax, ώστε στο τέλος να επιστρέψει την βέλτιστη κίνηση του Θησέα
        Node root = new Node();
        Board clone = new Board(board);
        root.setNodeBoard(clone);
        createMySubtree(currentPos, root, 1, arrM, Minotaur, Theseus, 0.0);
        
        //alpha for ab pruning

        // Node alpha = new Node(); 
        // alpha.setStepSon(alpha);
        // alpha.getStepSon().setNodeEvaluation(-100.0);


        //beta for ab pruning

        // Node beta = new Node(); 
        // beta.setStepSon(beta);
        // beta.getStepSon().setNodeEvaluation(100.0);


        // call minmax with ab pruning

        // Node bestdice = chooseMinMaxMove(root, true, alpha, beta);
        Node bestdice = chooseMinMaxMove(root, true); //tha epistrefei node kai apo to node tha pairnoyme to bestdice
        int retDice = bestdice.getNodeMove()[2];
        double[] eval = evaluate(currentPos, retDice, arrM, board);
        int[] inputPath = new int[4];

        // εδώ γεμίζουμε την path. Για να γίνει αυτό παίρνουμε τις θέσεις 1-4 του πίνακα που επιστρέφει η eval
        // αγγελική για σένα, η eval πλέον επιστρέφει πίνακα 5 θέσεων ώστε να γεμίσει η path σωστά
        for(int i = 1; i < 5; i++){
            inputPath[i-1] = (int)eval[i];
        }
        path.add(inputPath);

        
        return retDice;
    }

    
    public boolean validMove(int currentPos, int dice, Board board){ // Ελέγχει αν η κίνηση που θα κάνει στη δημιουργία του δέντρου είναι valid(δηλαδή αν υπάρχει τοίχος)
        switch (dice) {
            case 1: 
                if(board.tiles[currentPos].getUp()){
                    return false;
                }
                else return true;
            case 3: 
                if(board.tiles[currentPos].getRight()){
                    return false;
                }
                else return true;
            case 5: 
                if(board.tiles[currentPos].getDown()){
                    return false;
                }
                else return true;
            case 7: 
                if(board.tiles[currentPos].getLeft()){
                    return false;
                }
                else return true;
            default:
                return false;
        }
    }
    
    public void createMySubtree(int currentPos, Node root, int depth, int[] arrM, HeuristicPlayer Minotaur, MinMaxPlayer Theseus, double parentEval){ // δημιουργεί το subTree του Θησέα, από το οποίο θα διαλέξει το μέγιστο
        if(depth == this.treeDepth) return;

        for(int i = 0; i < 4; i++){
            int dice = 2*i + 1;
            Board clone = new Board(root.getNodeBoard());
            MinMaxPlayer clonePlayer = new MinMaxPlayer(0, Theseus.getPlayerId(), Theseus.getName(), Theseus.getScore(), Theseus.getX(), Theseus.getY(), clone);
            
            if(validMove(currentPos, dice, clone)){
                double[] eval = clonePlayer.evaluate(currentPos, dice, arrM, clone);
                int[] tempArr = clonePlayer.move(currentPos, dice, clone);  //ayto poy epistrefei h move apo ton theseus
                int[] nodeArr = new int[3]; 
                nodeArr[0] = tempArr[1]; //to x
                nodeArr[1] = tempArr[2]; //to y
                nodeArr[2] = dice; //to dice
                Node child = new Node(root, depth+1, nodeArr, clone, (eval[0] + parentEval));
                root.children.add(child);
                createOpponentSubtree(tempArr[0], arrM[0], child, depth+1, eval[0], Minotaur, clonePlayer, tempArr);
            } 
        }
    }

    public void createOpponentSubtree(int currentTheseusPos, int currentMinoPos, Node parent, int depth, double parentEval, HeuristicPlayer Minotaur, MinMaxPlayer Theseus, int[] arrT){ // δημιουργεί το subTree του Μινωταύρου, από το οποίο θα διαλέξει το ελάχιστο
        if(depth == this.treeDepth) return;

        for(int i = 0; i < 4; i++){
            int dice = 2*i + 1;
            Board clone = new Board(parent.getNodeBoard());
            HeuristicPlayer clonePlayer = new HeuristicPlayer(Minotaur.getPlayerId(), Minotaur.getName(), 0, Minotaur.getX(), Minotaur.getY(), clone);
            
            if(validMove(currentMinoPos, dice, clone)){
                double eval = clonePlayer.evaluate(currentMinoPos, dice, arrT, clone);
                int[] tempArr = clonePlayer.move(currentMinoPos, dice, clone);
                int[] nodeArr = new int[3];
                nodeArr[0] = tempArr[1]; //to x
                nodeArr[1] = tempArr[2]; //to y
                nodeArr[2] = dice; //to dice
                Node child = new Node(parent, depth+1, nodeArr, clone, (parentEval - eval));
                if(tempArr[0] == currentTheseusPos){
                    child.setNodeEvaluation(-10.0);
                    parent.children.add(child);
                    continue;
                }
                parent.children.add(child);
                createMySubtree(arrT[0], child, depth+1, tempArr, clonePlayer, Theseus, eval);
            } 
        }
    }



}

