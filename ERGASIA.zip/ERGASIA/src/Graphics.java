package src;

import java.awt.GraphicsConfiguration;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Graphics {

    int width;
    int height;
    int x;
    int y;

    JLabel label = new JLabel("Game has started! Round: 0");
    
    static GraphicsConfiguration gc;

    public Graphics(int width, int height, int x, int y){
        JFrame frame= new JFrame(gc);    
        frame.setTitle("Theseus and Minotaur");
        frame.setSize(width, height);
        frame.setLocation(x, y);
        
        JPanel panel = new JPanel();
        panel.add(label);
        frame.add(panel);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

    }

    public void updateText(String text){
        this.label.setText(text);
    }

}