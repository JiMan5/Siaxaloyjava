package src;
//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)


public class Game {
    int round; // ο τρέχον γύρος του παιχνιδιού

    public Game(){ // κενός constructor
        round = 0;
    }
    public Game(int round){ // constructor με ορίσματα
        this.round = round;
    }

    // setters και getters
    public int getRound(){
        return round;
    }
    public void setRound(int round){
        this.round = round;
    }
    // τέλος setters και getters

    public void printTable(int theseusTile, int minotaurTile, Board board, Game game){ // τυπώνει το board στη τρέχουσα κατάσταση
        String[][] toString = board.getStringRepresentation(theseusTile, minotaurTile, game); // το string που θα τυπωθεί
        for(int i = 0; i < 2 * board.getN() + 1; i++){
            for(int j = 0; j < board.getN(); j++){
                System.out.print(toString[i][j]);
            }
            System.out.println();
        }
    }

    public void show(int round, Board board, int[] arrT, int[] arrM, int winnerId, int n, int score, Game game){ // τυπώνει το status του παιχνιδιού
        System.out.println("Round: " + round);
        
        printTable(arrT[0], arrM[0], board, game);
        System.out.println(round % 2 == 1 ? ("Theseus is at tile " + arrT[0] + ".") : ("Minotaur is at tile " + arrM[0] + "."));
        System.out.println("Score: " + score);
        
        System.out.println();
        System.out.println();
        
        if(winnerId == 1){
            System.out.println("Theseus won!");
        }
        else if(winnerId == 2){
            System.out.println("The Minotaur won!");
        }
        
        else if(round == 2 * n){
            System.out.println("Game took way too long... Theseus died of starvation and Minotaur of boredom!");
            System.out.println();
        }
        
    }

    public static void main(String[] args) { // η main μέθοδος του παιχνιδιού
        int N = 3; // μέγεθος του πίνακα
        int S = 2; // αριθμός εφοδίων
        int W = (N * N * 3 + 1) / 2; // μέγιστος αριθμός τοιχών
        int n = 10; // αριθμός γύρων

        Game game = new Game(); // αντικείμενο τύπου Game
        Board board = new Board(N, S, W); // αντικείμενο τύπου Board
        board.createBoard();
        if(game.getRound() == 0){
            System.out.println("The Game begins. The initial board is as such."); 
            System.out.println("Round: 0");
        }
        game.printTable(0, (N * N) / 2, board, game);

        Player Theseus = new Player(1, "Theseus", 0, 0, 0, board); // παίκτης Θησέας
        Player Minotaur = new Player(2, "Minotaur", 0, N / 2, N / 2, board); // παίκτης Μινώταυρος

        boolean winner = false; // μεταβλητή για τον έλεγχο ύπαρξης νικητή
        int winnerId = 0; // 1 = Θησέας, 2 = Μινώταυρος

        int[] arrT = new int[4]; // πίνακας που θα επιστραφεί απο την μέθοδο move() του Player 1
        int[] arrM = new int[4]; // πίνακας που θα επιστραφεί απο την μέθοδο move() του Player 2
        arrM[0] = (N * N / 2);
        while(game.getRound() < (2 * n) && !winner){
            int dice = 2*(int)((Math.random()*100) % 4) + 1;
            if(game.getRound() % 2 == 0){
                arrT = Theseus.move((Theseus.getX()*N)+Theseus.getY(), dice, board);
            }
            else{
                arrM = Minotaur.move((Minotaur.getX()*N)+Minotaur.getY(), dice, board);
            }
            if(arrT[0] == arrM[0]){
                winner = true;
                winnerId = 2;
            }
            if(Theseus.getScore() == S){
                winner = !winner;
                winnerId = 1;
            } 
            
            game.setRound(game.getRound() + 1);
            game.show(game.getRound(), board, arrT, arrM, winnerId, n, Theseus.getScore(), game);
        }
    }
}
