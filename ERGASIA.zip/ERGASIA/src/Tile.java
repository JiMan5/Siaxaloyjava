package src;
//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)

public class Tile {

    int tileId;         // το id του πλακιδίου του ταμπλό
    int x;              // η συντεταγμένη x του πλακιδίου του ταμπλό
    int y;              // συντεταγμένη y του πλακιδίου του ταμπλό
    boolean up;         // δείχνει εάν υπάρχει τοίχος στη βόρεια (πάνω) πλευρά του πλακιδίου
    boolean down;       // δείχνει εάν υπάρχει τοίχος στην νότια (κάτω) πλευρά του πλακιδίου
    boolean left;       // δείχνει εάν υπάρχει τοίχος στη δυτική (αριστερή) πλευρά του πλακιδίου
    boolean right;      // δείχνει εάν υπάρχει τοίχος στην ανατολική (δεξιά) πλευρά του πλακιδίου
    boolean supply;     // δείχνει εάν το πλακίδιο έχει εφόδιο ή οχι


    public Tile(){      // κενός constructor
        tileId = 0;
        x = 0;
        y = 0;
        up = false;
        down = false;
        left = false;
        right = false;
        supply = false;
    }
    // constructor με ορίσματα
    public Tile(int tileId, int x, int y, boolean up, boolean down, boolean left, boolean right, boolean supply){
        this.tileId = tileId;
        this.x = x;
        this.y = y;
        this.up = up;
        this.down = down;
        this.left = left;
        this.right = right;
        this.supply = supply;
    }

    public Tile(Tile tile){             // constructor με όρισμα ένα αντικείμενο Tile
        this.tileId = tile.getTileId();
        this.x = tile.getX();
        this.y = tile.getY();
        this.up = tile.getUp();
        this.down = tile.getDown();
        this.left = tile.getLeft();
        this.right = tile.getRight();
        this.supply = tile.getSupply();
    }

    // ακολουθούν οι setters και οι getters της κλάσης Tile

    public void setTileId(int tileId){
        this.tileId = tileId;
    }

    public int getTileId(){
        return tileId;
    }

    public void setX(int x){
        this.x = x;
    }

    public int getX(){
        return x;
    }

    public void setY(int y){
        this.y = y;
    }

    public int getY(){
        return y;
    }

    public void setUp(boolean up){
        this.up = up;
    }

    public boolean getUp(){
        return up;
    }

    public void setDown(boolean down){
        this.down = down;
    }

    public boolean getDown(){
        return down;
    }

    public void setLeft(boolean left){
        this.left = left;
    }

    public boolean getLeft(){
        return left;
    }

    public void setRight(boolean right){
        this.right = right;
    }

    public boolean getRight(){
        return right;
    }

    public void setSupply(boolean supply){
        this.supply = supply;
    }

    public boolean getSupply(){
        return supply;
    }
    
}
