package src;

import java.util.ArrayList;

public class HeuristicPlayer extends Player {

    ArrayList<int[]> path = new ArrayList<>();

    static int counterUpT = 0;
    static int counterRightT = 0;
    static int counterDownT = 0;
    static int counterLeftT = 0;
    
    static int counterSupplies = 0;

    public HeuristicPlayer(){
        super();
    }

    public HeuristicPlayer(int playerId, String name, int score, int x, int y, Board board){
        super(playerId, name, score, x, y, board);
    }

    public void setElementArrayList(int[] arr) {
        this.path.add(arr);
    }

    public int[] getElementArrayList(int index){
        return this.path.get(index);
    }

    public double targetFunction(double supplyDist, double opponentDist){
        return supplyDist * 0.46 + (-opponentDist) * 0.54;
    }

    public double evaluate(int currentPos, int dice, int[] arrM){
        int supplyDist = 0;
        int opponentDist = 0;
        Board clone = new Board(this.board);
        ArrayList<int[]> info = new ArrayList<>();

        for(int i = 0; i < 3; i++){
            if(this.move(currentPos, dice, clone)[0] == currentPos){       // found wall
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = -1;                    // -1 if he has found wall
                tileInfo[2] = -1;
                info.add(i, tileInfo);
                break;
            }
            int[] arr = this.move(currentPos, dice, clone);
            if(arrM[0] == arr[0]){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 2;                    // 2 if he finds Minotaur
                tileInfo[2] = 0;
                info.add(i, tileInfo);
            }
            if(arr[3] != 0){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                if(tileInfo[1] != 2){
                    tileInfo[1] = 1;                // 1 if he finds a Supply
                }
                else tileInfo[2] = 1;
                info.add(i, tileInfo);
            }
            else{
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 0;                    // 0 if he finds nothing
                tileInfo[2] = 0;
                info.add(i, tileInfo);
            }

            currentPos = arr[0];
        }

        exit:
        for(int i = 0; i < 3; i++){
            for(int j = 1; j <= 2; j++){
                if(info.get(i)[j] == 1 && supplyDist == 0){
                    supplyDist = i + 1;
                }
                else if(info.get(i)[j] == 2 && opponentDist == 0){
                    opponentDist = i + 1;
                }
                else if(info.get(i)[j] == -1){
                    supplyDist = -2;
                    opponentDist = 2;
                    break exit;
                }
            }
        }

        int[]  pathInfo = new int[4];
        pathInfo[0] = dice;
        pathInfo[1] = (supplyDist == 1) ? 1 : 0;
        pathInfo[2] = supplyDist;
        pathInfo[3] = opponentDist;

        this.path.add(pathInfo);

        return targetFunction(supplyDist, opponentDist);

    }

    public int getNextMove(int currentPos, int round, int[] arrM) {

        double[] temparr = new double[2];
        ArrayList<double[]> posmove = new ArrayList<>();
        for(int i=0; i<4; i++){
            int dice = 2*i + 1;
            temparr[0] = (double)dice;
            temparr[1] = evaluate(currentPos, dice, arrM);
            posmove.add(temparr);
        }
        
        double max = -1000.0;
        int bestdice = 0;
        ArrayList<double[]> postemp= new ArrayList<>();
        for (int i = 0; i<4; i++){
            if(posmove.get(i)[1] > max){
                max = posmove.get(i)[1];
                bestdice = (int)posmove.get(i)[0];
            }
            if(posmove.get(i)[1] == max){
                postemp.add(posmove.get(i));
            } 
        }

        if(postemp.size() > 1){
            int index = (int)((Math.random()*100) % postemp.size());
            bestdice = (int)postemp.get(index)[0];
        }

        int counter = 0;
        for(int i = round; i < round + 4; i++){
            if(path.get(i)[0] != bestdice){
                path.remove(i); 
                i--;
                counter++;
            }
            if(counter == 3) break;
        }

        return bestdice;

    }

    public static void statistics(int n, HeuristicPlayer player, Game game, ArrayList<int[]> path){

        if(player.getPlayerId()==1){                    // Prints where Theseus decided to move and increases counter by one
            if(path.get(n)[0]==1){
                System.out.println("Theseus moved up");
                counterUpT++;
            }
            else if(path.get(n)[0]==3){
                System.out.println("Theseus moved right");
                counterRightT++;
            }
            else if(path.get(n)[0]==5){
                System.out.println("Theseus moved down");
                counterDownT++;
            }
            else if(path.get(n)[0]==7){
                System.out.println("Theseus moved left");
                counterLeftT++;
            }
        }

        System.out.println();

        System.out.println("Theseus has collected " + player.getScore() + "Supplies!"); // prints the supplies Theseus has collected

        System.out.println();
        
        System.out.println("Theseus is" + path.get(n)[2]+ "tiles away from the supply");  //Prints how many tiles away Theseus is from a supply

        System.out.println();
        if(game.getRound() == 2*n){     //Prints amount of times each move was chosen by each player 
            System.out.println("Theseus moved " + counterUpT + " times up");
            System.out.println("Theseus moved " + counterRightT + " times right");
            System.out.println("Theseus moved " + counterDownT + " times down");
            System.out.println("Theseus moved " + counterLeftT + " times left");
        }
    }

}
