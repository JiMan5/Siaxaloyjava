package src;

public class Game {
    int round;

    public Game(){
        //empty constructor
        round = 0;
    }
    public Game(int round){
        this.round = round;
    }
    public int getRound(){
        return round;
    }
    public void setRound(int round){
        this.round = round;
    }

    public void show(int round, Board board, int[] arrT, int[] arrM, int winnerId, int n, int score){
        System.out.println("Round: " + (round + 1));
        String[][] toString = board.getStringRepresentation(arrT[0], arrM[0]);
        for(int i = 0; i < 2 * board.getN() + 1; i++){
            for(int j = 0; j < board.getN(); j++){
                System.out.print(toString[i][j]);
            }
            System.out.println();
        }
        System.out.println(round % 2 == 0 ? ("Theseus is at tile " + arrT[0] + ".") : ("Minotaur is at tile " + arrM[0] + "."));
        System.out.println("Score: " + score);
        
        System.out.println();
        System.out.println();
        
        if(winnerId == 1){
            System.out.println("Theseus won!");
        }
        else if(winnerId == 2){
            System.out.println("The Minotaur won!");
        }
        
        else if(round == 2 * n - 1){
            System.out.println("Game took way too long... Theseus died of starvation and Minotaur of boredom!");
            System.out.println();
        }
        
    }

    public static void main(String[] args) {
        int N = 3;
        int S = 2;
        int W = (N * N * 3 + 1) / 2;
        int n = 10;

        Game game = new Game();
        Board board = new Board(N, S, W);
        board.createBoard();
        Player Theseus = new Player(1, "Theseus", 0, 0, 0, board);
        Player Minotaur = new Player(2, "Minotaur", 0, N / 2, N / 2, board);

        boolean winner = false;
        int winnerId = 0; // 1 = Theseus, 2 = Minotaur

        int[] arrT = new int[4];
        int[] arrM = new int[4];
        arrM[0] = (N*N / 2);
        while(game.getRound() < (2 * n) && !winner){
            if(game.getRound() % 2 == 0){
                arrT = Theseus.move((Theseus.getX()*N)+Theseus.getY());
            }
            else{
                arrM = Minotaur.move((Minotaur.getX()*N)+Minotaur.getY());
            }
            if(arrT[0] == arrM[0]){
                winner = true;
                winnerId = 2;
            } 
            if(arrT[3] != 0){
                Minotaur.board.supplies[arrT[3]].setSupplyTileId(0);
            }
            if(Theseus.getScore() == S){
                winner = !winner;
                winnerId = 1;
            } 
            
            game.show(game.getRound(), board, arrT, arrM, winnerId, n, Theseus.getScore());
            game.setRound(game.getRound() + 1);
        }

        /*int N = 7;
        Board board = new Board(N, 5, 4 * N - 1 + 15);
        board.createBoard();
        String[][] toString = board.getStringRepresentation(5, 3);
        for(int i = 0; i < 2 * N + 1; i++){
            for(int j = 0; j < N; j++){
                System.out.print(toString[i][j]);
            }
            System.out.println();
        }*/
    }
}
