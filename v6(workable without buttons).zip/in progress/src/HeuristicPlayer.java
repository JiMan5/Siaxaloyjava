import java.util.ArrayList;

public class HeuristicPlayer extends Player {

    static int counterUpT = 0; //πόσες φορές κινήθηκε προς τα πάνω ο πάικτης
    static int counterRightT = 0; //πόσες φορές κινήθηκε προς τα δεξιά ο πάικτης
    static int counterDownT = 0; //πόσες φορές κινήθηκε προς τα κάτω ο πάικτης
    static int counterLeftT = 0; //πόσες φορές κινήθηκε προς τα αριστερά ο πάικτης
    
    static int previousMove = 0;

    static int counterSupplies = 0; //πόσα supplies βρήκε ο παίκτης

    static int counterRound = 0;

    public HeuristicPlayer(){ //κενός constructor
        super();
    }

    public HeuristicPlayer(int playerId, String name, int score, int x, int y, Board board){ // constructor της κλάσης HeuristicPlayer με ορίσματα
        super(playerId, name, score, x, y, board);
    }

    public double targetFunction(int opponentDist){ 

        switch (opponentDist){ //ανάλογα με την απόσταση από τον Θησέα δίνεται μια τιμή πόντων
            case -1: return -2.0 * 0.54;
            case  0: return  0.0 * 0.54;
            case  1: return  1.0 * 0.54;
            case  2: return  0.5 * 0.54;
            case  3: return  0.3 * 0.54;
            default: return -10000.0;
        }

    }

    public double evaluate(int currentPos, int dice, int[] arrT, Board board){
        //
        int opponentDist = 0;
        Board clone = new Board(board);
        HeuristicPlayer clonePlayer = new HeuristicPlayer(this.playerId, this.name, this.score, this.x, this.y, clone);
        ArrayList<int[]> info = new ArrayList<>(); //μεταβλητη που κραταει πληροφορίες για
        for(int i = 0; i < 3; i++){
            int[] arr = clonePlayer.move(currentPos, dice, clone);
            if(arr[0] == currentPos){                  // found wall
                int[] tileInfo = new int[2];
                tileInfo[0] = i;
                tileInfo[1] = -1;                    // -1 αν βρει τοίχος
                info.add(tileInfo);
                break;
            }
            if(arrT[0] == arr[0]){
                int[] tileInfo = new int[2];
                tileInfo[0] = i;
                tileInfo[1] = 2;                    // 2 αν βρει τον Θησέα
                info.add(tileInfo);
            }
            else{
                int[] tileInfo = new int[2];
                tileInfo[0] = i;
                tileInfo[1] = 0;                    // 0 αν δεν βρει τίποτα
                info.add(tileInfo);
            }
            currentPos = arr[0];
        }

        for(int i = 0; i < 3; i++){
            if(info.get(i)[1] == 2){
                opponentDist = i + 1;  // found Theseus
            }
            else if(info.get(i)[1] == 0){
                opponentDist = 0;
            }
            else if(info.get(i)[1] == -1){
                if(i == 0){
                    opponentDist = -1;
                }
                break;
            }
        }

        return targetFunction(opponentDist); //επιστροφή αξίας κίνησης

    }

    public int getNextMove(int currentPos, int[] arrT, Board board) {
        //επιλογή της βέλτιστης κίνησης

        ArrayList<double[]> posmove = new ArrayList<>();
        for(int i=0; i<4; i++){
            int dice = 2*i + 1;
            double[] temparr = new double[2];
            temparr[0] = (double)dice;
            temparr[1] = evaluate(currentPos, dice, arrT, board);
            posmove.add(temparr);
        }

        double max = -1000.0;
        int bestdice = 0;
        ArrayList<double[]> postemp = new ArrayList<>();
        for (int i = 0; i<4; i++){
            if(posmove.get(i)[1] >= max){ //εύρεση της κίνησης με την μέγιστη αξία
                max = posmove.get(i)[1];
                bestdice = (int)posmove.get(i)[0];
            }
        }
        for(int i = 0; i < 4; i++){
            if(posmove.get(i)[1] == max){ //εύρεση κίνησης με αξία ισάξια με την μέγιστη (εάν υπάρχει)
                postemp.add(posmove.get(i));
            } 
        }
        
        if(postemp.size() > 1){  //τυχαία επιλογή μιας κίνησης αν υπάρχουν έστω δύο ισάξιες
            while(true){
                int index = (int)((Math.random()*100) % postemp.size());
                bestdice = (int)postemp.get(index)[0];
                if(bestdice != ((previousMove + 4)%8)) break;
            }
        }

        previousMove = bestdice; 
        //η μέθοδος είναι μη στατική επίτηδες.

        return bestdice;

    }
}
