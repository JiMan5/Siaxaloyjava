package src;

import java.util.ArrayList;

public class HeuristicPlayer extends Player {

    ArrayList<int[]> path = new ArrayList<>();

    static int counterUpT = 0;
    static int counterRightT = 0;
    static int counterDownT = 0;
    static int counterLeftT = 0;
    
    static int counterSupplies = 0;

    public HeuristicPlayer(){
        super();
    }

    public HeuristicPlayer(int playerId, String name, int score, int x, int y, Board board){
        super(playerId, name, score, x, y, board);
    }

    public void setElementArrayList(int[] arr) {
        this.path.add(arr);
    }

    public int[] getElementArrayList(int index){
        return this.path.get(index);
    }

    public double targetFunction(int supplyDist, int opponentDist){
        double sup = 0.0;
        double opp = 0.0;
        switch (supplyDist){
            case -1: sup = -2.0; break;
            case  0: sup =  0.0; break;
            case  1: sup =  1.0; break;
            case  2: sup =  0.5; break;
            case  3: sup =  0.3; break;
            default: break;
        }

        switch (opponentDist){
            case -1: opp = 2.0; break;
            case  0: opp = 0.0; break;
            case  1: opp = 1.0; break;
            case  2: opp = 0.5; break;
            case  3: opp = 0.3; break;
            default: break;
        }
        return sup * 0.46 + (-opp) * 0.54;
    }

    public double evaluate(int currentPos, int dice, int[] arrM){
        int supplyDist = 0;
        int opponentDist = 0;
        Board clone = new Board(this.board);
        HeuristicPlayer clonePlayer = new HeuristicPlayer(this.playerId, this.name, this.score, this.x, this.y, clone);
        ArrayList<int[]> info = new ArrayList<>();
        for(int i = 0; i < 3; i++){
            int[] arr = clonePlayer.move(currentPos, dice, clone);
            if(arr[0] == currentPos){                  // found wall
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = -1;                    // -1 if he has found wall
                tileInfo[2] = -1;
                info.add(tileInfo);
                break;
            }
            if(arrM[0] == arr[0]){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 2;                    // 2 if he finds Minotaur
                tileInfo[2] = 0;
                info.add(tileInfo);
            }
            if(arr[3] != -1){
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                if(tileInfo[1] != 2){
                    tileInfo[1] = 1;                // 1 if he finds a Supply
                }
                else tileInfo[2] = 1;
                info.add(tileInfo);
            }
            else{
                int[] tileInfo = new int[3];
                tileInfo[0] = i;
                tileInfo[1] = 0;                    // 0 if he finds nothing
                tileInfo[2] = 0;
                info.add(tileInfo);
            }
            currentPos = arr[0];
        }

        boolean flag = false;
        for(int i = 0; i < 3; i++){
            for(int j = 1; j <= 2; j++){
                if(info.get(i)[j] == 1 && supplyDist == 0){
                    supplyDist = i + 1;
                }
                else if(info.get(i)[j] == 2 && opponentDist == 0){
                    opponentDist = i + 1;
                }
                else if(info.get(i)[j] == -1){
                    if(i == 0){
                    supplyDist = -1;
                    opponentDist = -1;
                    }
                    flag = true;
                    break;
                }
            }
            if(flag) break;
        }

        int[]  pathInfo = new int[4];
        pathInfo[0] = dice;
        pathInfo[1] = (supplyDist == 1) ? 1 : 0;
        pathInfo[2] = supplyDist;
        pathInfo[3] = opponentDist;

        this.path.add(pathInfo);

        return targetFunction(supplyDist, opponentDist);

    }

    public int getNextMove(int currentPos, int round, int[] arrM) {

        ArrayList<double[]> posmove = new ArrayList<>();
        for(int i=0; i<4; i++){
            int dice = 2*i + 1;
            double[] temparr = new double[2];
            temparr[0] = (double)dice;
            temparr[1] = evaluate(currentPos, dice, arrM);
            // System.out.println("DICE: "+ temparr[0]);
            // System.out.println("EVALUATE GIA TO DICE AYTO: " + temparr[1]);
            posmove.add(temparr);
        }

        double max = -1000.0;
        int bestdice = 0;
        ArrayList<double[]> postemp= new ArrayList<>();
        for (int i = 0; i<4; i++){
            if(posmove.get(i)[1] >= max){
                max = posmove.get(i)[1];
                bestdice = (int)posmove.get(i)[0];
            }
        }
        for(int i = 0; i < 4; i++){
            if(posmove.get(i)[1] == max){
                postemp.add(posmove.get(i));
            } 
        }

        if(postemp.size() > 1){
            int index = (int)((Math.random()*100) % postemp.size());
            bestdice = (int)postemp.get(index)[0];
        }

        int counter = 0;
        for(int i = round; i < path.size(); i++){
            if(path.get(i)[0] != bestdice){
                path.remove(i);
                i--;
                counter++;
            }
            if(counter == 3) break;
        }
        return bestdice;

    }

    public static void statistics(int round, HeuristicPlayer player, Game game, ArrayList<int[]> path, int n, int realRound, boolean winner){                 
        // Prints where Theseus decided to move and increases counter by one
        
        if((realRound != 2*n + 1) && !winner){
            if(path.get(round-1)[0]==1){
                System.out.println("Theseus moved up!");
                counterUpT++;
            }
            else if(path.get(round-1)[0]==3){
                System.out.println("Theseus moved right!");
                counterRightT++;
            }
            else if(path.get(round-1)[0]==5){
                System.out.println("Theseus moved down!");
                counterDownT++;
            }
            else if(path.get(round-1)[0]==7){
                System.out.println("Theseus moved left!");
                counterLeftT++;
            }
    
            
            if(player.getScore() == 0){
                        System.out.println("Theseus has collected " + player.getScore() + " Supplies!");
            }
            else if(player.getScore() == 1){
                System.out.println("Theseus has collected " + player.getScore() + " Supply!");
            }
            else{
                System.out.println("Theseus has collected " + player.getScore() + " Supplies!");
            }
            
            
            if(path.get(round-1)[2] == 0){
                System.out.println("There are no supplies in Theseus' visual field");
            }
            else if(path.get(round-1)[2] == 1){
                System.out.println("Theseus was " + path.get(round-1)[2]+ " tile away from the supply");
            }
            else{
                System.out.println("Theseus was " + path.get(round-1)[2]+ " tiles away from the supply");
            }   //Prints how many tiles away Theseus is from a supply
    
            
            if(path.get(round-1)[3] == 0){
                System.out.println("Theseus doesn't see the Minotaur!");
            }
            else if(path.get(round-1)[3] == 1){
                System.out.println("Theseus was " + path.get(round-1)[3]+ " tile away from Minotaur!");
            }
            else{
                System.out.println("Theseus was " + path.get(round-1)[3]+ " tiles away from Minotaur!");
            } 
        }
        
        else{
            System.out.println();
            System.out.println("GAME STATISTICS:");
            System.out.println("Theseus moved " + counterUpT + " times up");
            System.out.println("Theseus moved " + counterRightT + " times right");
            System.out.println("Theseus moved " + counterDownT + " times down");
            System.out.println("Theseus moved " + counterLeftT + " times left");
        }
    }
}
